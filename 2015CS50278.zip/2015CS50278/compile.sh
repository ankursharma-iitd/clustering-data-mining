#!/bin/bash

g++ dbscan.cpp std=c++11 -O3 -o dbscan
g++ kmeans.cpp std=c++11 -O3 -o kmeans