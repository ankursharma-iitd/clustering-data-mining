#!/bin/bash

git clone https://github.com/ankursharma-iitd/clustering-data-mining.git
pip3 install -U numpy scipy scikit-learn matplotlib shapely
